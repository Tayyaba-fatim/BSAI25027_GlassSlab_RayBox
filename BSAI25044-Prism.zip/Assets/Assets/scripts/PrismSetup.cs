using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshCollider))]
public class PrismSetup : MonoBehaviour
{
    public float apexAngle = 60f;
    public float height = 2f;
    public float depth = 1f;

    void Awake()
    {
        Mesh mesh = BuildMesh();

        GetComponent<MeshFilter>().mesh = mesh;

        MeshCollider mc = GetComponent<MeshCollider>();
        mc.sharedMesh = null;       // force refresh
        mc.convex = true;
        mc.sharedMesh = mesh;
    }

    Mesh BuildMesh()
    {
        float halfApex = apexAngle * 0.5f * Mathf.Deg2Rad;
        float halfBase = height * Mathf.Tan(halfApex);
        float cy = height / 3f;

        Vector3 apex = new Vector3(0f, height - cy, 0f);
        Vector3 bl = new Vector3(-halfBase, -cy, 0f);
        Vector3 br = new Vector3(halfBase, -cy, 0f);
        float hd = depth * 0.5f;

        Vector3[] verts =
        {
            apex + Vector3.forward * hd,   // 0
            bl   + Vector3.forward * hd,   // 1
            br   + Vector3.forward * hd,   // 2
            apex + Vector3.back    * hd,   // 3
            bl   + Vector3.back    * hd,   // 4
            br   + Vector3.back    * hd,   // 5
        };

        int[] tris =
        {
            0,2,1,  3,4,5,   // front + back caps
            0,1,4,  0,4,3,   // left face
            0,3,5,  0,5,2,   // right face
            1,2,5,  1,5,4,   // base
        };

        Mesh mesh = new Mesh();
        mesh.name = "TriangularPrism";
        mesh.vertices = verts;
        mesh.triangles = tris;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        return mesh;
    }
}