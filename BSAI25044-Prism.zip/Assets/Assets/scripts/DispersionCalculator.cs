using UnityEngine;

public struct SpectralBand
{
    public string label;
    public float wavelengthNm;
    public float refractiveIndex;
    public Color colour;

    public SpectralBand(string label, float wavelengthNm, float n, Color colour)
    {
        this.label = label;
        this.wavelengthNm = wavelengthNm;
        this.refractiveIndex = n;
        this.colour = colour;
    }
}

public class DispersionCalculator
{
    public float CauchyA;
    public float CauchyB;

    // baseRefractiveIndex is n at 550 nm (green reference)
    public DispersionCalculator(float baseRefractiveIndex = 1.5f)
    {
        CauchyB = 0.00420f;          // crown glass typical value (μm²)
        float lam = 0.550f;          // 550 nm in micrometres
        CauchyA = baseRefractiveIndex - CauchyB / (lam * lam);
    }

    // λ in nanometres
    public float RefractiveIndexAt(float wavelengthNm)
    {
        float lam = wavelengthNm * 0.001f;   // nm → μm
        return CauchyA + CauchyB / (lam * lam);
    }

    // Returns 7-band ROYGBIV array
    public SpectralBand[] GetROYGBIV()
    {
        return new SpectralBand[]
        {
            new SpectralBand("Red",    700f, RefractiveIndexAt(700f), new Color(1f,   0f,   0f)),
            new SpectralBand("Orange", 620f, RefractiveIndexAt(620f), new Color(1f,   0.5f, 0f)),
            new SpectralBand("Yellow", 580f, RefractiveIndexAt(580f), new Color(1f,   1f,   0f)),
            new SpectralBand("Green",  550f, RefractiveIndexAt(550f), new Color(0f,   1f,   0f)),
            new SpectralBand("Blue",   470f, RefractiveIndexAt(470f), new Color(0f,   0.5f, 1f)),
            new SpectralBand("Indigo", 430f, RefractiveIndexAt(430f), new Color(0.3f, 0f,   0.8f)),
            new SpectralBand("Violet", 400f, RefractiveIndexAt(400f), new Color(0.6f, 0f,   1f)),
        };
    }

    // Returns just 3 bands (R, G, B) for simpler mode
    public SpectralBand[] GetRGB()
    {
        return new SpectralBand[]
        {
            new SpectralBand("Red",   700f, RefractiveIndexAt(700f), new Color(1f, 0f,   0f)),
            new SpectralBand("Green", 550f, RefractiveIndexAt(550f), new Color(0f, 1f,   0f)),
            new SpectralBand("Blue",  430f, RefractiveIndexAt(430f), new Color(0f, 0.2f, 1f)),
        };
    }

    public SpectralBand[] GetBands(int count)
    {
        return count >= 7 ? GetROYGBIV() : GetRGB();
    }
}