using UnityEngine;

public class RayRefraction
{
    /// <summary>
    /// Vector form of Snell's Law.
    /// incident  = normalised ray direction (pointing INTO surface)
    /// normal    = outward face normal
    /// Returns false on Total Internal Reflection.
    /// </summary>
    public bool Refract(Vector3 incident, Vector3 normal,
                        float n1, float n2, out Vector3 refracted)
    {
        incident = incident.normalized;
        normal = normal.normalized;

        // Ensure normal opposes the ray
        float cosI = Vector3.Dot(-incident, normal);
        if (cosI < 0f) { normal = -normal; cosI = -cosI; }

        float ratio = n1 / n2;
        float sinT2 = ratio * ratio * (1f - cosI * cosI);

        if (sinT2 > 1f)              // Total Internal Reflection
        {
            refracted = Vector3.Reflect(incident, normal);
            return false;
        }

        float cosT = Mathf.Sqrt(1f - sinT2);
        refracted = (ratio * incident + (ratio * cosI - cosT) * normal).normalized;
        return true;
    }

    /// <summary>Angle of deviation: δ = (i1 + i2) − A  (degrees)</summary>
    public float Deviation(float angleIn, float angleOut, float apexAngle)
        => (angleIn + angleOut) - apexAngle;

    /// <summary>Minimum deviation for symmetric ray path (degrees)</summary>
    public float MinDeviation(float apexAngleDeg, float n)
    {
        float half = apexAngleDeg * 0.5f * Mathf.Deg2Rad;
        float iMin = Mathf.Asin(Mathf.Clamp(n * Mathf.Sin(half), -1f, 1f)) * Mathf.Rad2Deg;
        return 2f * iMin - apexAngleDeg;
    }

    /// <summary>Critical angle for TIR (degrees), going dense→rare</summary>
    public float CriticalAngle(float n) => Mathf.Asin(1f / n) * Mathf.Rad2Deg;
}