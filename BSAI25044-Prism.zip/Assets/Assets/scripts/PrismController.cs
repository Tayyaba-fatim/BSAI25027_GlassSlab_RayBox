using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshCollider))]
public class PrismController : MonoBehaviour
{
    [Header("Prism Geometry")]
    public float apexAngleDegrees = 60f;

    [Header("Glass Properties")]
    public float baseRefractiveIndex = 1.5f;

    [Header("Dispersion")]
    public bool dispersionEnabled = true;
    [Range(3, 7)] public int spectralBands = 7;

    [Header("Ray Appearance")]
    public float rayWidth = 0.05f;
    public float rayLength = 20f;

    [Header("Debug")]
    public bool showDebugInfo = true;

    // ── internal ──────────────────────────────────────────
    private DispersionCalculator dispersion;
    private RayRefraction refraction;
    private List<LineRenderer> spectralRays = new();
    private LineRenderer incidentLine;
    private bool receivedThisFrame;

    void Awake()
    {
        dispersion = new DispersionCalculator(baseRefractiveIndex);
        refraction = new RayRefraction();
        BuildLineRenderers();
        HideRays();
    }

    void LateUpdate()
    {
        // If ReceiveRay wasn't called this frame the ray has moved away
        if (!receivedThisFrame) HideRays();
        receivedThisFrame = false;
    }

    // ── Keyboard rotation (same feel as GlassSlab) ────────
    void Update()
    {
        var kb = UnityEngine.InputSystem.Keyboard.current;
        if (kb == null) return;
        if (kb.leftArrowKey.isPressed) transform.Rotate(0, 0, 1f);
        if (kb.rightArrowKey.isPressed) transform.Rotate(0, 0, -1f);
    }

    // ── Public API ────────────────────────────────────────

    /// Called by LightRayBox (via PrismRayReceiver) each frame.
    public void ReceiveRay(Vector3 origin, Vector3 dir,
                           Vector3 hitPoint, Vector3 entryNormal)
    {
        receivedThisFrame = true;
        dir = dir.normalized;

        SpectralBand[] bands = dispersionEnabled
            ? dispersion.GetBands(spectralBands)
            : new[] { new SpectralBand("White", 550f, baseRefractiveIndex, Color.white) };

        // Show correct number of lines
        for (int i = 0; i < spectralRays.Count; i++)
            spectralRays[i].enabled = i < bands.Length;

        for (int i = 0; i < bands.Length; i++)
        {
            var band = bands[i];

            // ── Entry refraction  (air → glass) ───────────
            bool entryOk = refraction.Refract(
                dir, entryNormal, 1.0f, band.refractiveIndex,
                out Vector3 insideDir);

            if (!entryOk) { spectralRays[i].enabled = false; continue; }

            // ── Find exit face ─────────────────────────────
            if (!FindExitFace(hitPoint, insideDir, out RaycastHit exitHit))
            { spectralRays[i].enabled = false; continue; }

            // ── Exit refraction  (glass → air) ─────────────
            bool exitOk = refraction.Refract(
                insideDir, exitHit.normal, band.refractiveIndex, 1.0f,
                out Vector3 outsideDir);

            // ── Draw three-point ray path ──────────────────
            var lr = spectralRays[i];
            lr.material.color = band.colour;
            lr.startColor = lr.endColor = band.colour;
            lr.positionCount = 3;
            lr.SetPosition(0, hitPoint);
            lr.SetPosition(1, exitHit.point);
            lr.SetPosition(2, exitHit.point + (exitOk ? outsideDir : Vector3.Reflect(insideDir, exitHit.normal)) * rayLength);

            // ── Debug output ───────────────────────────────
            if (showDebugInfo)
            {
                float angleIn = Vector3.Angle(-dir, entryNormal);
                float deviation = exitOk
                    ? refraction.Deviation(angleIn,
                                           Vector3.Angle(outsideDir, -exitHit.normal),
                                           apexAngleDegrees)
                    : float.NaN;
                float dMin = refraction.MinDeviation(apexAngleDegrees, band.refractiveIndex);
                float tir = refraction.CriticalAngle(band.refractiveIndex);

                Debug.Log($"[Prism] {band.label} λ={band.wavelengthNm:F0}nm " +
                          $"n={band.refractiveIndex:F4} | " +
                          $"θ_in={angleIn:F1}°  δ={deviation:F1}°  " +
                          $"δ_min={dMin:F1}°  θ_c={tir:F1}°");
            }
        }

        // Draw white incident segment
        incidentLine.enabled = true;
        incidentLine.SetPosition(0, origin);
        incidentLine.SetPosition(1, hitPoint);
    }

    public void HideRays()
    {
        foreach (var lr in spectralRays) lr.enabled = false;
        if (incidentLine != null) incidentLine.enabled = false;
    }

    // ── Private helpers ───────────────────────────────────

    bool FindExitFace(Vector3 from, Vector3 dir, out RaycastHit hit)
    {
        // Offset slightly inside to avoid re-hitting the entry face
        Vector3 origin = from + dir.normalized * 0.003f;
        hit = default;

        RaycastHit[] hits = Physics.RaycastAll(origin, dir, 10f);
        float best = float.MaxValue;
        bool found = false;

        foreach (var h in hits)
        {
            if (h.collider.gameObject == gameObject && h.distance < best)
            { best = h.distance; hit = h; found = true; }
        }
        return found;
    }

    void BuildLineRenderers()
    {
        // 7 spectral rays
        for (int i = 0; i < 7; i++)
        {
            var go = new GameObject($"SpectralRay_{i}");
            go.transform.parent = transform;
            var lr = go.AddComponent<LineRenderer>();
            lr.positionCount = 3;
            lr.useWorldSpace = true;
            lr.startWidth = lr.endWidth = rayWidth;
            lr.material = new Material(Shader.Find("Unlit/Color"));
            lr.enabled = false;
            spectralRays.Add(lr);
        }

        // White incident segment
        var ig = new GameObject("IncidentLine");
        ig.transform.parent = transform;
        incidentLine = ig.AddComponent<LineRenderer>();
        incidentLine.positionCount = 2;
        incidentLine.useWorldSpace = true;
        incidentLine.startWidth = incidentLine.endWidth = rayWidth;
        var m = new Material(Shader.Find("Unlit/Color"));
        m.color = Color.white;
        incidentLine.material = m;
        incidentLine.enabled = false;
    }
}