using UnityEngine;

public class LightRayBox : MonoBehaviour
{
    [Header("Ray Settings")]
    public bool isOn = false;
    public float rayWidth = 0.05f;
    public float rayLength = 20f;

    [Header("Angle Control")]
    public float rayAngle = 0f;

    private LineRenderer mainRay;
    private GlassSlab lastHitSlab = null;
    private PrismRayReceiver lastHitPrism = null;

    void Start()
    {
        // Create only ONE ray line from box
        GameObject obj = new GameObject("MainRay");
        obj.transform.parent = transform;
        mainRay = obj.AddComponent<LineRenderer>();
        mainRay.startWidth = rayWidth;
        mainRay.endWidth = rayWidth;
        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = Color.yellow;
        mainRay.material = mat;
        mainRay.positionCount = 2;
        mainRay.useWorldSpace = true;

        //  HIDDEN at start - only shows when Space pressed
        mainRay.enabled = false;
    }

    void Update()
    {
        var kb = UnityEngine.InputSystem.Keyboard.current;

        if (kb.spaceKey.wasPressedThisFrame)
        {
            isOn = !isOn;

            if (!isOn)
            {
                mainRay.enabled = false;
                if (lastHitSlab != null) lastHitSlab.HideRays();
                if (lastHitPrism != null) lastHitPrism.HideRays();  // ✅ added
            }
        }

        if (kb.upArrowKey.isPressed) rayAngle += 1f;
        if (kb.downArrowKey.isPressed) rayAngle -= 1f;

        if (isOn)
        {
            mainRay.enabled = true;  // ✅ removed the HideRays call
            ShootRay();
        }
    }

    void ShootRay()
    {
       
        //  Ray starts from RIGHT side of box (front face)
        Vector3 startPos = transform.position +
                            transform.right * 0.3f;

        //  Direction based on angle adjustment
        Vector3 direction = Quaternion.Euler(0, 0, rayAngle) *
                            transform.right;
        Debug.Log("Hit: " + (Physics.Raycast(startPos, direction, out RaycastHit dbg, rayLength) ? dbg.collider.name : "nothing"));
        RaycastHit hit;
        if (Physics.Raycast(startPos, direction, out hit, rayLength))
        {
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, hit.point);

            // Check if hit Glass Slab
            GlassSlab slab = hit.collider.GetComponent<GlassSlab>();
            PrismRayReceiver prism = hit.collider.GetComponent<PrismRayReceiver>();

            if (slab != null)
            {
                if (lastHitPrism != null) lastHitPrism.HideRays();
                lastHitSlab = slab; lastHitPrism = null;
                slab.ReceiveRay(startPos, direction, Vector3.Angle(direction, -hit.normal));
            }
            else if (prism != null)
            {
                if (lastHitSlab != null) lastHitSlab.HideRays();
                lastHitSlab = null; lastHitPrism = prism;
                prism.ReceiveRay(startPos, direction, hit.point, hit.normal);
            }
            else
            {
                if (lastHitSlab != null) lastHitSlab.HideRays();
                if (lastHitPrism != null) lastHitPrism.HideRays();
                lastHitSlab = null; lastHitPrism = null;
            }
        }
        else
        {
            // Nothing hit, draw full ray, hide slab rays
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, startPos + direction * rayLength);

            if (lastHitPrism != null) lastHitPrism.HideRays();
            lastHitPrism = null; 
            if (lastHitSlab != null)
                lastHitSlab.HideRays();
        }
    }
}