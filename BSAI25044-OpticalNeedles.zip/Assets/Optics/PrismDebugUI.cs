using System.Collections.Generic;
using UnityEngine;

namespace Optics
{
    /// <summary>
    /// On-screen debug panel for PrismModule.
    /// Shows per-wavelength optical data and key summary statistics.
    /// Enable via the Inspector; disable in builds where you don't need it.
    /// </summary>
    [RequireComponent(typeof(PrismModule))]
    [AddComponentMenu("Optics/Prism Debug UI")]
    public class PrismDebugUI : MonoBehaviour
    {
        [Header("Display")]
        public bool showPanel = true;
        public Vector2 panelPosition = new Vector2(10, 10);
        public int fontSize = 13;

        private PrismModule _prism;
        private GUIStyle _style;
        private GUIStyle _headerStyle;

        private void Awake()
        {
            _prism = GetComponent<PrismModule>();
        }

        private void OnGUI()
        {
            if (!showPanel) return;
            InitStyles();

            var results = _prism.TraceAll();
            var lines = BuildLines(results);
            float width = 480f;
            float height = (lines.Count + 2) * (fontSize + 4) + 40f;

            var rect = new Rect(panelPosition.x, panelPosition.y, width, height);
            GUI.Box(rect, "");
            GUILayout.BeginArea(new Rect(rect.x + 8, rect.y + 8, rect.width - 16, rect.height - 16));

            GUILayout.Label("OPTICAL PRISM  —  Debug Panel", _headerStyle);
            GUILayout.Space(4);

            foreach (var (label, value, color) in lines)
            {
                _style.normal.textColor = color;
                GUILayout.Label($"{label,-26} {value}", _style);
            }

            GUILayout.EndArea();
        }

        private List<(string, string, Color)> BuildLines(List<PrismTraceResult> results)
        {
            var list = new List<(string, string, Color)>();
            Color white = Color.white;
            Color yellow = Color.yellow;
            Color cyan = Color.cyan;
            Color orange = new Color(1f, 0.6f, 0f);

            // Prism info
            list.Add(("Apex Angle", $"{_prism.apexAngleDeg:F1}°", white));
            list.Add(("Material", _prism.material.ToString(), white));
            list.Add(("Incidence Angle", $"{_prism.incidenceAngleDeg:F2}°", cyan));
            list.Add(("", "", white));

            // Per-wavelength
            list.Add(("λ (nm)   n        δ (°)    e (°)", "", yellow));
            list.Add(("─────────────────────────────────", "", yellow));

            float minDev = float.MaxValue, maxDev = float.MinValue;
            foreach (var r in results)
            {
                string devStr = r.totalInternalReflection ? "TIR" : $"{r.deviationAngleDeg:F2}°";
                string eStr = r.totalInternalReflection ? "—" : $"{r.emergenceAngleDeg:F2}°";
                list.Add(($"{r.wavelengthNm:F0} nm  {r.refractiveIndex:F4}  {devStr,-9} {eStr}",
                          "", r.color));

                if (!r.totalInternalReflection)
                {
                    if (r.deviationAngleDeg < minDev) minDev = r.deviationAngleDeg;
                    if (r.deviationAngleDeg > maxDev) maxDev = r.deviationAngleDeg;
                }
            }

            // Summary
            list.Add(("", "", white));
            if (results.Count > 0)
            {
                float critAngle = _prism.CriticalAngle(589f); // sodium D line
                float minDevCalc = _prism.MinimumDeviationAngle(589f);
                list.Add(("Critical Angle (589 nm)", $"{critAngle:F2}°", orange));
                list.Add(("Min. Deviation (589 nm)", float.IsNaN(minDevCalc) ? "TIR" : $"{minDevCalc:F2}°", orange));

                if (maxDev > float.MinValue && minDev < float.MaxValue)
                    list.Add(("Dispersion Spread", $"{(maxDev - minDev):F2}°", orange));
            }

            return list;
        }

        private void InitStyles()
        {
            if (_style != null) return;

            _style = new GUIStyle(GUI.skin.label)
            {
                fontSize = fontSize,
                fontStyle = FontStyle.Normal,
            };
            _headerStyle = new GUIStyle(_style)
            {
                fontSize = fontSize + 1,
                fontStyle = FontStyle.Bold,
                normal = { textColor = Color.cyan },
            };
        }
    }
}