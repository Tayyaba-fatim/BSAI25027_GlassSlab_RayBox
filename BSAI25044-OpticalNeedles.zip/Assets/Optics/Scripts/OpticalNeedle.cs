using UnityEngine;

[ExecuteAlways]
public class OpticalNeedle : MonoBehaviour
{
    [Header("Needle Settings")]
    public float length = 1f;
    public Color needleColor = Color.red;

    [Header("Ray Settings")]
    public bool drawRay = true;
    public float rayLength = 3f;
    public Color rayColor = Color.yellow;
    public float rayWidth = 0.01f;

    [Header("Snapping")]
    public bool snapToGrid = true;
    public float gridSize = 0.1f;
    public bool snapToAngles = true;
    public float angleStep = 15f;

    private Transform body;
    private Transform tip;
    private LineRenderer lineRenderer;

    void Start()
    {
        FindParts();
        UpdateNeedleVisuals();
    }

    void FindParts()
    {
        body = transform.Find("Body");
        tip = transform.Find("Tip");
        lineRenderer = GetComponent<LineRenderer>();
    }

    void UpdateNeedleVisuals()
    {
        if (body != null)
        {
            body.localPosition = new Vector3(0, length / 2, 0);
            body.localScale = new Vector3(0.04f, length, 0.04f);
            body.GetComponent<Renderer>().sharedMaterial.color = needleColor;
        }

        if (tip != null)
        {
            tip.localPosition = new Vector3(0, length, 0);
            tip.GetComponent<Renderer>().sharedMaterial.color = needleColor;
        }
    }

    void Update()
    {
        ApplySnapping();

        if (drawRay)
            DrawRay();
        else if (lineRenderer != null)
            lineRenderer.enabled = false;
    }

    void ApplySnapping()
    {
        if (snapToGrid)
        {
            Vector3 pos = transform.position;
            pos.x = Mathf.Round(pos.x / gridSize) * gridSize;
            pos.y = Mathf.Round(pos.y / gridSize) * gridSize;
            pos.z = Mathf.Round(pos.z / gridSize) * gridSize;
            transform.position = pos;
        }

        if (snapToAngles)
        {
            Vector3 angles = transform.eulerAngles;
            angles.x = Mathf.Round(angles.x / angleStep) * angleStep;
            angles.y = Mathf.Round(angles.y / angleStep) * angleStep;
            angles.z = Mathf.Round(angles.z / angleStep) * angleStep;
            transform.eulerAngles = angles;
        }
    }

    void DrawRay()
    {
        if (lineRenderer == null) return;

        lineRenderer.enabled = true;
        Vector3 tipWorld = transform.TransformPoint(new Vector3(0, length, 0));
        Vector3 direction = transform.up;
        Vector3 endPoint = tipWorld + direction * rayLength;

        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, tipWorld);
        lineRenderer.SetPosition(1, endPoint);
        lineRenderer.startColor = rayColor;
        lineRenderer.endColor = rayColor;
        lineRenderer.startWidth = rayWidth;
        lineRenderer.endWidth = rayWidth;
    }

    void OnDrawGizmosSelected()
    {
        Vector3 tipPos = transform.TransformPoint(new Vector3(0, length, 0));
        Gizmos.color = Color.white;
        Gizmos.DrawWireCube(tipPos, Vector3.one * 0.1f);

        // Draw alignment cross
        Gizmos.color = Color.green;
        Gizmos.DrawLine(tipPos - Vector3.right * 0.2f, tipPos + Vector3.right * 0.2f);
        Gizmos.DrawLine(tipPos - Vector3.forward * 0.2f, tipPos + Vector3.forward * 0.2f);
    }
}