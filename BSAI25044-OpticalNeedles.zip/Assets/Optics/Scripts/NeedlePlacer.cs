using UnityEngine;

public class NeedlePlacer : MonoBehaviour
{
    public GameObject needlePrefab;
    public LayerMask placementLayer = ~0;

    [Header("Placement Settings")]
    public KeyCode placeKey = KeyCode.Mouse0;
    public KeyCode deleteKey = KeyCode.Delete;
    public bool alignToSurface = true;

    private Camera mainCamera;
    private OpticalNeedle selectedNeedle;

    void Start()
    {
        mainCamera = Camera.main;

        // Load prefab from Resources if not assigned
        if (needlePrefab == null)
            needlePrefab = Resources.Load<GameObject>("OpticalNeedle");
    }

    void Update()
    {
        HandlePlacement();
        HandleSelection();
        HandleDeletion();
    }

    void HandlePlacement()
    {
        if (Input.GetKeyDown(placeKey) && !IsMouseOverUI())
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out RaycastHit hit, 100f, placementLayer))
            {
                GameObject newNeedle = Instantiate(needlePrefab, hit.point, Quaternion.identity);

                if (alignToSurface)
                {
                    newNeedle.transform.up = hit.normal;
                }

                // Auto-select the new needle
                selectedNeedle = newNeedle.GetComponent<OpticalNeedle>();
            }
            else
            {
                // Place in air at fixed distance
                Vector3 pos = mainCamera.transform.position + mainCamera.transform.forward * 2f;
                Instantiate(needlePrefab, pos, Quaternion.identity);
            }
        }
    }

    void HandleSelection()
    {
        if (Input.GetMouseButtonDown(1)) // Right click to select
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out RaycastHit hit, 100f))
            {
                OpticalNeedle needle = hit.collider.GetComponentInParent<OpticalNeedle>();
                if (needle != null)
                {
                    selectedNeedle = needle;
                    Debug.Log($"Selected: {selectedNeedle.name}");

                    // Optional: Highlight selected needle
                    HighlightNeedle(selectedNeedle);
                }
            }
        }
    }

    void HandleDeletion()
    {
        if (Input.GetKeyDown(deleteKey) && selectedNeedle != null)
        {
            Destroy(selectedNeedle.gameObject);
            selectedNeedle = null;
        }
    }

    void HighlightNeedle(OpticalNeedle needle)
    {
        // Simple highlight - change color temporarily
        // You can implement a proper outline effect here
    }

    bool IsMouseOverUI()
    {
        return UnityEngine.EventSystems.EventSystem.current != null &&
               UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject();
    }
}