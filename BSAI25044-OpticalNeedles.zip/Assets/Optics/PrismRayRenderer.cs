using System.Collections.Generic;
using UnityEngine;

namespace Optics
{
    /// <summary>
    /// Attaches to the same GameObject as PrismModule and draws the refracted /
    /// dispersed ray paths at runtime using LineRenderers.
    ///
    /// One LineRenderer is created per wavelength so each ray can be coloured
    /// independently. All children are pooled and reused across frames so the
    /// component is allocation-free during gameplay.
    /// </summary>
    [RequireComponent(typeof(PrismModule))]
    [AddComponentMenu("Optics/Prism Ray Renderer")]
    public class PrismRayRenderer : MonoBehaviour
    {
        [Header("Line Appearance")]
        [Tooltip("Width of each light-ray line.")]
        [Min(0.001f)]
        public float lineWidth = 0.02f;

        [Tooltip("Material used for each LineRenderer. Should use an Unlit/Transparent or Particles shader.")]
        public Material rayMaterial;

        [Tooltip("Multiplies the ray colour for HDR / bloom support.")]
        [Min(0f)]
        public float colorIntensity = 2f;

        [Header("Update")]
        [Tooltip("Recalculate rays every frame. Disable for static setups.")]
        public bool liveUpdate = true;

        // ── Internal ─────────────────────────────────────────────────────────

        private PrismModule _prism;
        private List<LineRenderer> _pool = new List<LineRenderer>();
        private List<PrismTraceResult> _cache = new List<PrismTraceResult>();

        private void Awake()
        {
            _prism = GetComponent<PrismModule>();
        }

        private void Start() => Refresh();
        private void Update() { if (liveUpdate) Refresh(); }

        // ─────────────────────────────────────────────────────────────────────
        //  Public API
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>Force an immediate recalculation and redraw.</summary>
        public void Refresh()
        {
            _cache = _prism.TraceAll();
            Debug.Log("Rays cached: " + _cache.Count); // <--- ADD THIS
            UpdateLines(_cache);
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Internals
        // ─────────────────────────────────────────────────────────────────────

        private void UpdateLines(List<PrismTraceResult> results)
        {
            EnsurePool(results.Count);

            for (int i = 0; i < _pool.Count; i++)
            {
                if (i >= results.Count)
                {
                    _pool[i].gameObject.SetActive(false);
                    continue;
                }

                var r = results[i];
                var lr = _pool[i];
                lr.gameObject.SetActive(true);

                var pts = r.pathPoints;
                int count = r.totalInternalReflection ? 3 : 4;
                lr.positionCount = count;
                for (int j = 0; j < count; j++)
                    lr.SetPosition(j, pts[j]);

                Color c = r.color * colorIntensity;
                lr.startColor = c;
                lr.endColor = new Color(c.r, c.g, c.b, 0.2f); // fade out
                lr.startWidth = lineWidth;
                lr.endWidth = lineWidth * 0.5f;
            }
        }

        private void EnsurePool(int needed)
        {
            while (_pool.Count < needed)
            {
                var go = new GameObject($"Ray_{_pool.Count:D2}");
                go.transform.SetParent(transform, false);

                var lr = go.AddComponent<LineRenderer>();
                lr.useWorldSpace = true;
                lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                lr.receiveShadows = false;
                lr.numCapVertices = 4;

                if (rayMaterial != null) lr.material = rayMaterial;

                _pool.Add(lr);
            }
        }

        private void OnDestroy()
        {
            foreach (var lr in _pool)
                if (lr != null) Destroy(lr.gameObject);
            _pool.Clear();
        }
    }
}