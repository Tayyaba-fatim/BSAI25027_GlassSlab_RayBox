// Place this file in any Editor/ folder inside your project.
// It will only be compiled in the Editor and will not be included in builds.
#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

namespace Optics.Editor
{
    [CustomEditor(typeof(PrismModule))]
    public class PrismModuleEditor : UnityEditor.Editor
    {
        private PrismModule _prism;
        private bool _showCalcPanel = true;
        private bool _showRayTable = true;

        private void OnEnable()
        {
            _prism = (PrismModule)target;
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("── Optical Calculations ──", EditorStyles.boldLabel);

            _showCalcPanel = EditorGUILayout.Foldout(_showCalcPanel, "Key Values (sodium D-line 589 nm)", true);
            if (_showCalcPanel) DrawKeyValues();

            EditorGUILayout.Space(4);
            _showRayTable = EditorGUILayout.Foldout(_showRayTable, "Dispersion Table (all wavelengths)", true);
            if (_showRayTable) DrawDispersionTable();

            if (GUILayout.Button("Log Full Trace to Console"))
                LogTrace();
        }

        // ─── Key values panel ─────────────────────────────────────────────────

        private void DrawKeyValues()
        {
            EditorGUI.indentLevel++;
            float n = _prism.RefractiveIndex(589f);
            float crit = _prism.CriticalAngle(589f);
            float minD = _prism.MinimumDeviationAngle(589f);

            EditorGUILayout.LabelField("Refractive Index n(589 nm)", n.ToString("F5"));
            EditorGUILayout.LabelField("Critical Angle (589 nm)", $"{crit:F3}°");
            EditorGUILayout.LabelField("Min. Deviation  (589 nm)",
                float.IsNaN(minD) ? "TIR – ray trapped" : $"{minD:F3}°");

            // Show deviation for current incidence
            var r = _prism.Trace(589f, Color.yellow);
            if (r.HasValue)
            {
                var res = r.Value;
                if (!res.totalInternalReflection)
                    EditorGUILayout.LabelField("Deviation @ current i", $"{res.deviationAngleDeg:F3}°");
                else
                    EditorGUILayout.LabelField("Deviation @ current i", "TIR at second face");
            }
            EditorGUI.indentLevel--;
        }

        // ─── Dispersion table ─────────────────────────────────────────────────

        private void DrawDispersionTable()
        {
            var results = _prism.TraceAll();
            if (results.Count == 0)
            {
                EditorGUILayout.HelpBox("No rays traced (check incidence angle).", MessageType.Info);
                return;
            }

            EditorGUI.indentLevel++;
            float dispersionSpread = 0f;
            float minDev = float.MaxValue, maxDev = float.MinValue;

            foreach (var res in results)
            {
                Color savedBg = GUI.backgroundColor;
                GUI.backgroundColor = new Color(res.color.r * 0.6f, res.color.g * 0.6f, res.color.b * 0.6f, 1f);

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField($"λ = {res.wavelengthNm:F0} nm",
                    EditorStyles.boldLabel);
                EditorGUILayout.LabelField("  n", res.refractiveIndex.ToString("F5"));

                if (res.totalInternalReflection)
                {
                    EditorGUILayout.LabelField("  Status", "Total Internal Reflection");
                }
                else
                {
                    EditorGUILayout.LabelField("  r₁ (refraction 1)", $"{res.refractionAngle1Deg:F3}°");
                    EditorGUILayout.LabelField("  r₂ (internal 2)", $"{res.internalAngle2Deg:F3}°");
                    EditorGUILayout.LabelField("  e  (emergence)", $"{res.emergenceAngleDeg:F3}°");
                    EditorGUILayout.LabelField("  δ  (deviation)", $"{res.deviationAngleDeg:F3}°");

                    if (res.deviationAngleDeg < minDev) minDev = res.deviationAngleDeg;
                    if (res.deviationAngleDeg > maxDev) maxDev = res.deviationAngleDeg;
                }

                EditorGUILayout.EndVertical();
                GUI.backgroundColor = savedBg;
                EditorGUILayout.Space(2);
            }

            if (maxDev > float.MinValue && minDev < float.MaxValue)
            {
                dispersionSpread = maxDev - minDev;
                EditorGUILayout.LabelField("Dispersion Spread (δ_red − δ_violet)",
                    $"{dispersionSpread:F3}°", EditorStyles.boldLabel);
            }

            EditorGUI.indentLevel--;
        }

        private void LogTrace()
        {
            Debug.Log($"[PrismModule] Apex={_prism.apexAngleDeg}°  Material={_prism.material}  " +
                      $"Incidence={_prism.incidenceAngleDeg}°");
            foreach (var r in _prism.TraceAll())
                Debug.Log(PrismModule.Summarise(r));
        }
    }
}
#endif