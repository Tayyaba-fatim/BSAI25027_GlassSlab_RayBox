using UnityEngine;

public class LightRayBox : MonoBehaviour
{
    [Header("Ray Settings")]
    public bool isOn = false;
    public float rayWidth = 0.05f;
    public float rayLength = 20f;

    [Header("Angle Control")]
    public float rayAngle = 0f;

    private LineRenderer mainRay;
    private GlassSlab lastHitSlab = null;

    void Start()
    {
        // Create only ONE ray line from box
        GameObject obj = new GameObject("MainRay");
        obj.transform.parent = transform;
        mainRay = obj.AddComponent<LineRenderer>();
        mainRay.startWidth = rayWidth;
        mainRay.endWidth = rayWidth;
        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = Color.yellow;
        mainRay.material = mat;
        mainRay.positionCount = 2;
        mainRay.useWorldSpace = true;

        //  HIDDEN at start - only shows when Space pressed
        mainRay.enabled = false;
    }

    void Update()
    {
        var kb = UnityEngine.InputSystem.Keyboard.current;

        // Space = toggle ray ON/OFF
        if (kb.spaceKey.wasPressedThisFrame)
        {
            isOn = !isOn;

            if (!isOn)
            {
                // turn everything off
                mainRay.enabled = false;
                if (lastHitSlab != null)
                    lastHitSlab.HideRays();
            }
        }

        //  UP/DOWN arrow keys to change angle (no W/S)
        if (kb.upArrowKey.isPressed) rayAngle += 1f;
        if (kb.downArrowKey.isPressed) rayAngle -= 1f;

        // Only shoot when ON
        if (isOn)
        {
            mainRay.enabled = true;
            ShootRay();
        }
    }

    void ShootRay()
    {
        //  Ray starts from RIGHT side of box (front face)
        Vector3 startPos = transform.position +
                            transform.right * 0.3f;

        //  Direction based on angle adjustment
        Vector3 direction = Quaternion.Euler(0, 0, rayAngle) *
                            transform.right;

        RaycastHit hit;
        if (Physics.Raycast(startPos, direction, out hit, rayLength))
        {
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, hit.point);

            // Check if hit Glass Slab
            GlassSlab slab = hit.collider.GetComponent<GlassSlab>();
            if (slab != null)
            {
                lastHitSlab = slab;
                float angle = Vector3.Angle(direction, -hit.normal);
                slab.ReceiveRay(startPos, direction, angle);
            }
            else
            {
                // Hit something else, hide slab rays
                if (lastHitSlab != null)
                    lastHitSlab.HideRays();
            }
        }
        else
        {
            // Nothing hit, draw full ray, hide slab rays
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, startPos + direction * rayLength);

            if (lastHitSlab != null)
                lastHitSlab.HideRays();
        }
    }
}